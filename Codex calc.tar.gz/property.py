from copy import copy
class Property:

    def __init__(self, property_key, value=None, name='Property', description='', hidden=False, *mutators):
        self.base = value
        self.propertyKey = property_key
        self.name = name
        self.description = description
        self.hidden = hidden
        self.mutators = dict(map(lambda x:(x.name,x),mutators))

    def add_mutator(self, other):
        self.mutators.append(other)

    def __delitem__(self, key):
        if key not in self.mutators:
            raise KeyError('item is not in the object\'s properties')
        else:
            del self.mutators[key]

    def __getitem__(self, item):
        if item not in self.mutators:
            raise KeyError('item is not in the object\'s properties')
        else:
            return self.mutators[item]

    def __call__(self, **kwargs):
        val = self.base
        mutators = sorted(self.mutators.values(), key=lambda x: x.priority)
        for mutator in mutators:
            val = mutator(val, **kwargs)
        return val

    def __str__(self):
        return '{}: {}'.format(self.name,self.base)

    def make(self, value):
        retval = copy(self)
        retval.base = value
        return retval


# class Mutator:
#     def __init__(self, mutator,property, priority,name, description, hidden = False):
#         self.property = property
#         self.name = name
#         self.description = description
#         self.mutator = mutator
#         self.priority = priority
#         self.hidden = hidden
#
#     def __call__(self, value, **kwargs):
#         return self.mutator(value, **kwargs)
#
#     def __str__(self):
#         return "|".join((self.name, self.priority, self.description))



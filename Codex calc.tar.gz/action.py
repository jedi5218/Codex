from copy import copy
from entity import Entity,EntityView
from enum import Enum


class Action:
    def __init__(self, key, duration, function, triggers, name, description):
        self.name = name
        self.key = key
        self.description = description
        self.duration = duration
        self.function = function
        self.triggers = triggers
        self.actor = None

    def __call__(self, **kwargs):
        for key in kwargs.keys():
            if isinstance(kwargs[key], Entity):
                kwargs[key].timer -= self.duration
                kwargs[key] = EntityView(kwargs[key], key)
        if self.actor:
            self.function(**kwargs, this=EntityView(self.actor, 'this'))
        else:
            self.function(**kwargs)


class MutatorType(Enum):
    globalMutator = 0
    eventMutator = 1
    localMutator = 2


class Mutator:
    def __init__(self, type: MutatorType, property, priority, mutator):
        self.type = type
        self.property = property
        self.priority = priority
        self.mutator = mutator

    def __call__(self, *args, **kwargs):
        return self.mutator(*args, **kwargs)


def action(this, target):
    print('badunkadunk!')
    target.base.guack -= this.guack

if __name__ == '__main__':
    from property import Property
    doThaThing = Action('do_the_thing', 1, action, 'step','Do the thing', '')
    guack = Property('guack', 100)
    bob = Entity('Bob',False, guack,doThaThing)
    bib = Entity('Bib',False, guack.make(20),doThaThing)
    bob.do_the_thing(bib)
